package in.ineuron.coreJava6;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Random;

public class StreamAPIOperations {
    public static void main(String[] args) {

        //Taking large data set numbers from 1 to 100
        List<Integer> numbers = new ArrayList<>();

        Random random = new Random();

        //Storing random numbers from 1 to 100
        for (int i = 1; i <= 100; i++) {
            numbers.add(random.nextInt(100));
        }

        // Perform operations using Stream API
        List<Integer> oddNumbers = numbers.stream()
                .filter(n -> n % 2 != 0) // Filtering only even elements
                .collect(Collectors.toList()); // Collect the filtered elements into a new list

        List<Integer> sortedNumbers = numbers.stream()
                .sorted() // Sort the numbers in natural order
                .collect(Collectors.toList()); // Collecting sorted elements into a new list

        System.out.println("Odd elements: " + oddNumbers);
        System.out.println("Sorted elements: " + sortedNumbers);
    }
}
