package in.ineuron.coreJava5;

public interface InterfaceA {


        void a();
        default void d(){
            System.out.println("A default method body.");
        }

}
