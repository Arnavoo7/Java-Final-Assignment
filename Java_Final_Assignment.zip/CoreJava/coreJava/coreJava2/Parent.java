package in.ineuron.coreJava2;

public class Parent {

    /*
        Constructor:
        ____________

        - Here, we are creating a Parent class constructor (Non-parameterized constructor).
        - A constructor name is same as Class name.
        - A constructor doesn't have a return type.
        - The Parent class constructor is invoked automatically when Child class constructor
          is invoked because of the super() which calls Parent class constructor.

    */

    int a=6;
    Parent()
    {
        System.out.println("Hello! I'm from Parent class");
    }

}
