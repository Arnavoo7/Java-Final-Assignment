package in.ineuron.coreJava9;

import java.util.Queue;
import java.util.LinkedList;

public class ProducerConsumer {
    public static void main(String[] args) {

        // Creating a queue to hold the produced numbers
        Queue<Integer> queue = new LinkedList<>();

        // Set the maximum size of the queue
        int maxSize = 5;

        // Create the producer thread
        Thread producerThread = new Thread(() -> {
            while (true) {
                // Apply object-level lock on the queue
                synchronized (queue) {
                    // Wait while the queue is full
                    while (queue.size() == maxSize) {
                        try {
                            System.out.println("Queue is full. Producer is waiting...");
                            // Release the lock and wait for notification
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    // Generating random number and adding it to the queue
                    int number = (int) (Math.random() * 100);
                    System.out.println("Producing: " + number);
                    queue.add(number);
                    
                    // Notify all waiting threads that the queue is not empty
                    queue.notifyAll();
                }
            }
        });

        // Create the consumer thread
        Thread consumerThread = new Thread(() -> {
            while (true) {
                // Apply object-level lock on the queue
                synchronized (queue) {
                    // Wait while the queue is empty
                    while (queue.isEmpty()) {
                        try {
                            System.out.println("Queue is empty. Consumer is waiting...");
                            // Release the lock and wait for notification
                            queue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    // Consume all the numbers in the queue and calculate their sum
                    int sum = 0;
                    while (!queue.isEmpty()) {
                        int number = queue.poll();
                        System.out.println("Consuming: " + number);
                        sum += number;
                    }
                    System.out.println("Sum: " + sum);
                    
                    // Notify all waiting threads that the queue is not full
                    queue.notifyAll();
                }
            }
        });

        // Start the producer and consumer threads
        producerThread.start();
        consumerThread.start();
    }
}


