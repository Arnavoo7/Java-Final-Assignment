package in.ineuron.coreJava4;

public interface IBank {
    float setDeposit(float amount,float bal);
    float setWithdraw(float amount,float bal);


}
