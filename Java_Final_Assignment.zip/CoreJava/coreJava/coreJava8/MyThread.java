package in.ineuron.coreJava8;


public class MyThread {

    public static void main(String[] args) {

        Thread t1 = new Thread(() -> {
            System.out.println(Thread.currentThread().getName());

            //Even number for Thread 1
            for(int i=2; i<10; i += 2){
                System.out.println(i);
            }
        });

        Thread t2 = new Thread( () -> {
            System.out.println(Thread.currentThread().getName());

            //Even number for Thread 1
            for(int i=3; i<10; i += 2){
                System.out.println(i);
            }

        });

        t1.start();
        t2.start();

        //System.out.println("Thread-"+Thread.currentThread().getName());

    }
}
