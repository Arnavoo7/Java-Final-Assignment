package com.TwentyOne.DataInsertion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class DataInsertionApplication {


    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(DataInsertionApplication.class, args);
        StudentService studentService = context.getBean(StudentService.class);

        // Create a new student object
        Student student = new Student();
        student.setName("Avatar");
        student.setAge(101);

        // Insert the student into the database
        studentService.createStudent(student);
    }
}
