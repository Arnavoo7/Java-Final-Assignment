package com.TwentyOne.DataInsertion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataInsertionApplicationTests {

	@Test
	void contextLoads() {
	}

}
