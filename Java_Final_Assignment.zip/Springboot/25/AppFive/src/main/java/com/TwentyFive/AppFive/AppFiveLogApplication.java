package com.TwentyFive.AppFive;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppFiveLogApplication implements CommandLineRunner {

    @Autowired
    private LogService logService;

    public static void main(String[] args) {
        SpringApplication.run(AppFiveLogApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n"+logService.doSomething());
        
        int sum = logService.calculateSum(5, 10);
        System.out.println("\nSum returned: " + sum);
    }
}
