package com.TwentySix.AppSix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppSixApplicationTests {

	@Test
	void contextLoads() {
	}

}
