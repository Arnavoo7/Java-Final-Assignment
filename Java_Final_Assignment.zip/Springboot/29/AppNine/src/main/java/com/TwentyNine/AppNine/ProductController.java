//Step 1: Initialize the products: http://localhost:8080/products/initialize
//Step 2: Get the products added:  http://localhost:8080/products
//Step 3: Filtered products: http://localhost:8080/products/filtered
//Step 4: Filter by name: http://localhost:8080/products/filtered?name=Product 1
//Step 5: Filter it by price: http://localhost:8080/products/filtered?maxPrice=50
//Step 6: sorting : http://localhost:8080/products/filtered?sort=name,desc




package com.TwentyNine.AppNine;

import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {
   
	private final ProductRepository productRepository;
		
		
	    public ProductController(ProductRepository productRepository) {
	        this.productRepository = productRepository;
	    }

    
    //http://localhost:8080/products/initialize
    @GetMapping("/initialize")
    @Transactional
    public String initializeProducts() {
        Product product1 = new Product();
        product1.setName("Product 1");
        product1.setDescription("Description 1");
        product1.setPrice(10.0);

        Product product2 = new Product();
        product2.setName("Product 2");
        product2.setDescription("Description 2");
        product2.setPrice(20.0);

        productRepository.saveAll(List.of(product1, product2));
        
        return "Products have been initialized.";

    }

    //http://localhost:8080/products
    @GetMapping
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @GetMapping("/filtered")
    public List<Product> getFilteredProducts(@RequestParam(required = false) String name,
                                             @RequestParam(required = false) Double minPrice,
                                             @RequestParam(required = false) Double maxPrice,
                                             @RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "10") int size,
                                             @RequestParam(defaultValue = "id") String sortField,
                                             @RequestParam(defaultValue = "asc") String sortDirection) {

        Sort.Direction direction = Sort.Direction.fromString(sortDirection);
        Sort sortCriteria = Sort.by(direction, sortField);
        Pageable pageable = PageRequest.of(page, size, sortCriteria);

        Specification<Product> spec = Specification.where(null);
        if (name != null) {
            spec = spec.and(ProductSpecifications.nameContainsIgnoreCase(name.toLowerCase()));
        }
        if (minPrice != null) {
            spec = spec.and(ProductSpecifications.priceGreaterThanOrEqual(minPrice));
        }
        if (maxPrice != null) {
            spec = spec.and(ProductSpecifications.priceLessThanOrEqual(maxPrice));
        }



        return productRepository.findAll(spec, pageable).getContent();
    }

  
}
