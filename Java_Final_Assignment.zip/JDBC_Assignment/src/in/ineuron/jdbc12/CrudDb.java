package in.ineuron.jdbc12;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;
import java.util.Scanner;

public class CrudDb {

    public static void main(String[] args) {

        ResultSet result = null;
        ResultSet result1 = null;
        int rcount = 0;
        int ucolumn = 0;

        String url = "jdbc:mysql://localhost:3306/proj1";
        String user = "root";
        String pass = "Password123#@!";
        String query = "";

        System.out.println("1. Creating a Table");
        System.out.println("2. Insert a Record");
        System.out.println("3. Read from Table");
        System.out.println("4. Update a Record");
        System.out.println("5. Delete a Record");

        System.out.print("Enter your choice: ");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();

        if (choice == 1)
            query = "CREATE TABLE project3(id INT(3) PRIMARY KEY AUTO_INCREMENT, name VARCHAR(30), age INT(2))";
        else if (choice == 2) {
            query = "INSERT INTO project3(`name`,`age`)VALUES(?,?)";
        } else if (choice == 3)
            query = "SELECT * FROM project3";
        else if (choice == 4) {
            System.out.println("\nWhich column you want to update:\n 1. name\n 2. age");

            ucolumn = sc.nextInt();

            if (ucolumn == 1)
                query = "UPDATE project3 SET name = ? WHERE id = ?";
            else if (ucolumn == 2) {
                query = "UPDATE project3 SET age = ? WHERE id = ?";
            }
        } else if (choice == 5) {
                query = "DELETE FROM project3 WHERE id = ? ";
        }

        try {

            //Step 1: Load and Register of Driver class automatically done

            //Step 2: Establishing the connection to DB
            Connection connect = DriverManager.getConnection(url, user, pass);

            //Step 3: Creating a PrepareStatement and send the query
            PreparedStatement stmt = connect.prepareStatement(query);

            //Step 4: Execute the query
            if (choice == 1) {
                stmt.executeUpdate();

                //Step 5: Print the result
                System.out.println("\nMessage: Table created.");
            } else if (choice == 2) {

                System.out.print("Enter name: ");
                sc.nextLine();

                String name = sc.nextLine();
                System.out.print("Enter age: ");
                int age = sc.nextInt();

                stmt.setString(1, name);
                stmt.setInt(2, age);

                rcount = stmt.executeUpdate();
                System.out.println("\nMessage: " + rcount + " row inserted.");

            } else if (choice == 3) {
                result = stmt.executeQuery();

                System.out.println("\nid" + "\t\t" + "name" + "\t\t" + "age");
                //Step 5: Get the result
                while (result.next()) {
                    System.out.println(result.getInt("id") + "\t\t" + result.getString("name") + "\t\t" + result.getInt("age"));
                }
            } else if (choice == 4) {

                System.out.println("See the Table for data:");
                String query1 = "SELECT * FROM project3";
                PreparedStatement stmt1 = connect.prepareStatement(query1);
                result1 = stmt1.executeQuery();

                System.out.println("\nid" + "\t\t" + "name" + "\t\t" + "age");
                //Step 5: Get the result
                while (result1.next()) {
                    System.out.println(result1.getInt("id") + "\t\t" + result1.getString("name") + "\t\t" + result1.getInt("age"));
                }
                    System.out.println("\nProvide the condition for targeting a specific record: ");

                    if (ucolumn == 1) {
                        System.out.print("Enter name: ");
                        sc.nextLine();
                        String name = sc.nextLine();

                        System.out.print("Enter id: ");
                        int id = sc.nextInt();

                        stmt.setString(1, name);
                        stmt.setInt(2, id);

                    }

                    if (ucolumn == 2) {
                        System.out.print("Enter age: ");
                        int age = sc.nextInt();

                        System.out.print("Enter id: ");
                        int id = sc.nextInt();

                        stmt.setInt(1, age);
                        stmt.setInt(2, id);

                    }

                    rcount = stmt.executeUpdate();
                    System.out.println("\nMessage: " + rcount + " row inserted.");

                } else if (choice == 5) {
                System.out.println("See the Table for data:");
                String query1 = "SELECT * FROM project3";
                PreparedStatement stmt1 = connect.prepareStatement(query1);
                result1 = stmt1.executeQuery();

                System.out.println("\nid" + "\t\t" + "name" + "\t\t" + "age");
                //Step 5: Get the result
                while (result1.next()) {
                    System.out.println(result1.getInt("id") + "\t\t" + result1.getString("name") + "\t\t" + result1.getInt("age"));
                }

                System.out.println("\nProvide the id to delete a specific record: ");
                System.out.print("Enter id: ");
                int id = sc.nextInt();
                stmt.setInt(1,id);

                rcount = stmt.executeUpdate();
                System.out.println("\nMessage: " + rcount + " row deleted.");

            }
        } catch (SQLException | NullPointerException e) {
            e.printStackTrace();

        }
    }
}
