package com.tut.ProjectName18;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.List;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");

        // View data from the "Project" table
        viewData();
    }

   

    private static void viewData() {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();

        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        // Fetch all records from the "Project" table using HQL query
        Query<Project> query = session.createQuery("FROM Project", Project.class);
        List<Project> projects = query.list();

        // Print the details of each project
        for (Project project : projects) {
            System.out.println(project);
        }

        tx.commit();
        session.close();
        factory.close();
    }
}
