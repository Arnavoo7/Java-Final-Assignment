package in.ineuron.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SessionManagement extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String name = (String) session.getAttribute("name");

        response.setContentType("text/html");
        response.getWriter().println("<html>");
        response.getWriter().println("<body>");

        if (name != null) {
            response.getWriter().println("<h1>Hello, " + name + "!</h1>");
            response.getWriter().println("<a href=\"servlet2\">Go to Page 2</a>");
        } else {
            response.getWriter().println("<h1>Please enter your name:</h1>");
            response.getWriter().println("<form action=\"session\" method=\"POST\">");
            response.getWriter().println("<input type=\"text\" name=\"name\">");
            response.getWriter().println("<input type=\"submit\" value=\"Submit\">");
            response.getWriter().println("</form>");
        }

        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String name = request.getParameter("name");

        // Store the user's name in the session
        session.setAttribute("name", name);

        response.setContentType("text/html");
        response.getWriter().println("<html>");
        response.getWriter().println("<body>");
        response.getWriter().println("<h1>Hello, " + name + "!</h1>");
        response.getWriter().println("<a href=\"servlet2\">Go to Page 2</a>");
        response.getWriter().println("</body>");
        response.getWriter().println("</html>");
    }
}
