package com.tut.ProjectName20;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");

        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        SessionFactory factory = cfg.buildSessionFactory();

        Session session = factory.openSession();
        Transaction tx = session.beginTransaction();

        // Updating the project with id no. for address change
        Project project = session.get(Project.class, 103);
        if (project != null) {
            project.setSaddress("BLR");
            session.update(project);
            System.out.println("Data updated successfully...");
        } else {
            System.out.println("Project not found with id 1");
        }

        // Retrieve all projects from the database
        List<Project> projects = session.createQuery("FROM Project", Project.class).list();

        // Print the details of each project
        for (Project proj : projects) {
            System.out.println(proj);
        }

        tx.commit();
        session.close();
    }
}
