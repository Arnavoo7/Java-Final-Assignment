package com.TwentyFive.AppFive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppFiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
