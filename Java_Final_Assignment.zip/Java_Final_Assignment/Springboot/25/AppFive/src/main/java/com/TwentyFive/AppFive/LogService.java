package com.TwentyFive.AppFive;

import org.springframework.stereotype.Service;

@Service
public class LogService {

    public String doSomething() {
        return ("Doing something...");
    }

    public int calculateSum(int a, int b) {
        int sum = a + b;
//        System.out.println("Sum: " + sum);
        return sum;
    }
}

