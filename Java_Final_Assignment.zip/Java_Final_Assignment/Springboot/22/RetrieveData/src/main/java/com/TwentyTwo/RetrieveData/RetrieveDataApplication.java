package com.TwentyTwo.RetrieveData;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetrieveDataApplication implements CommandLineRunner {
	
	private final UserRepository userRepository;
    private final OrderRepository orderRepository;

    @Autowired
    public RetrieveDataApplication(UserRepository userRepository,OrderRepository orderRepository) {
    	this.userRepository = userRepository;
        this.orderRepository = orderRepository;
    }

    public static void main(String[] args) {
        SpringApplication.run(RetrieveDataApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Insert sample orders for testing
        User user = new User();
        user.setName("Nitin M");
        User savedUser = userRepository.save(user);

        Order order1 = new Order();
        order1.setProductName("Product 1");
        order1.setUser(savedUser);
        orderRepository.save(order1);

        Order order2 = new Order();
        order2.setProductName("Product 2");
        order2.setUser(savedUser);
        orderRepository.save(order2);

        // Retrieve orders based on the user ID
        Long userId = savedUser.getId();
        List<Order> orders = orderRepository.findByUserId(userId);
        
        
        //Printing the retrieved orders
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getId());
            System.out.println("Product Name: " + order.getProductName());
            System.out.println("User ID: " + order.getUser().getId());
            System.out.println("User Name: " + order.getUser().getName());
            System.out.println("-------------------------------------");
        }
    }
}


