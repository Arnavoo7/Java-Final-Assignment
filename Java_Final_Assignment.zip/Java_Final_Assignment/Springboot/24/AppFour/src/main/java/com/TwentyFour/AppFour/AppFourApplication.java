//Suing cURL or POSTMAN
//curl -X POST -H "Content-Type: application/json" -d '{"name":"Arnab","email":"arnab@gmail.com"}' http://localhost:8080/api/users


package com.TwentyFour.AppFour;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class AppFourApplication {
    public static void main(String[] args) {
        SpringApplication.run(AppFourApplication.class, args);
    }
}

