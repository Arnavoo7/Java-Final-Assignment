package com.TwentyFour.AppFour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppFourApplicationTests {

	@Test
	void contextLoads() {
	}

}
