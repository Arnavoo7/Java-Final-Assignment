/*When a request is made to the /api/hello/{name} endpoint, the sayHello method will be called. It includes a simulated long-running 
operation (5 seconds sleep) to demonstrate the timeout scenario. If the method takes longer than the configured timeout or encounters 
an error, Hystrix will trigger and invoke the fallbackHello method, which will return a fallback greeting message.*/

package in.ineuron.restcontroller;


import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ApiController {

    @GetMapping("/hello/{name}")
    @HystrixCommand(fallbackMethod = "fallbackHello")
    public String sayHello(@PathVariable String name) {
        // Simulate a long-running operation
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return "Hello, " + name + "!";
    }

    public String fallbackHello(String name) {
        return "Fallback Hello, " + name + "!";
    }
}

