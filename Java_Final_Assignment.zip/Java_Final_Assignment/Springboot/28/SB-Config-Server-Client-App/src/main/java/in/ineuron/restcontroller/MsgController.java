package in.ineuron.restcontroller;

//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cloud.context.config.annotation.RefreshScope;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/api/test")
//@RefreshScope
//public class MsgController {
//
//	@Value("${msg:Config Server not working , plz check...}")
//	public String msg;
//
//	@GetMapping("/greet")
//	public ResponseEntity<String> showMsg() {
//		return new ResponseEntity<String>(msg, HttpStatus.OK);
//	}
//
//}


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/test")
@RefreshScope
public class MsgController {

    @Autowired
    private Environment environment;

    @GetMapping("/db-details")
    public ResponseEntity<String> getDbDetails() {
        String dbUrl = environment.getProperty("database.url");
        String dbUsername = environment.getProperty("database.username");
        String dbPassword = environment.getProperty("database.password");

        String response = "Database URL: " + dbUrl + "\n"
                        + "Username: " + dbUsername + "\n"
                        + "Password: " + dbPassword;

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}

