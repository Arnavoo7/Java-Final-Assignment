//Step 1: Running the app sample products will be initialized. 
//Step 2: Retrieving the products: http://localhost:8080/products
//Step 3: Retrieves a product by its ID: http://localhost:8080/products/1
//Step 4: For PUT and DELETE we can use chrome's REST CLIENT API


package com.TwentySix.AppSix;

import com.TwentySix.AppSix.dto.*;

import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@Configuration
@RestController
@RequestMapping("/products")
public class ProductController {
    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }
    
    @Bean
    public ApplicationRunner initializeProducts(ProductRepository productRepository) {
        return args -> {
            Product product1 = new Product();
            product1.setName("Product 1");
            product1.setDescription("Description of Product 1");
            product1.setPrice(9.99);
            productRepository.save(product1);

            Product product2 = new Product();
            product2.setName("Product 2");
            product2.setDescription("Description of Product 2");
            product2.setPrice(19.99);
            productRepository.save(product2);

            
            System.out.println("Sample products initialized.");
        };
    }

    @GetMapping
    public ResponseEntity<List<ProductResponseDTO>> getAllProducts() {
        List<Product> products = productRepository.findAll();
        List<ProductResponseDTO> responseDTOs = products.stream()
                .map(this::convertToResponseDTO)
                .collect(Collectors.toList());
        return new ResponseEntity<>(responseDTOs, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductResponseDTO> getProductById(@PathVariable("id") Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found"));
        ProductResponseDTO responseDTO = convertToResponseDTO(product);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<ProductResponseDTO> createProduct(@RequestBody ProductRequestDTO request,
                                                            UriComponentsBuilder uriBuilder) {
        Product product = convertToEntity(request);

        Product savedProduct = productRepository.save(product);

        URI location = uriBuilder.path("/products/{id}").buildAndExpand(savedProduct.getId()).toUri();
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(location);

        ProductResponseDTO responseDTO = convertToResponseDTO(savedProduct);
        return new ResponseEntity<>(responseDTO, headers, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductResponseDTO> updateProduct(@PathVariable("id") Long id,
                                                            @RequestBody ProductRequestDTO request) {
        Product existingProduct = productRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found"));

        existingProduct.setName(request.getName());
        existingProduct.setDescription(request.getDescription());
        existingProduct.setPrice(request.getPrice());

        Product updatedProduct = productRepository.save(existingProduct);
        ProductResponseDTO responseDTO = convertToResponseDTO(updatedProduct);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable("id") Long id) {
        Product existingProduct = productRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found"));

        productRepository.delete(existingProduct);
        return ResponseEntity.noContent().build();
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleAllExceptions(Exception ex) {
        // Log the exception if necessary

        String errorMessage = StringUtils.hasText(ex.getMessage()) ? ex.getMessage() : "An unexpected error occurred";
        ErrorResponse errorResponse = new ErrorResponse(errorMessage);
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private ProductResponseDTO convertToResponseDTO(Product product) {
        ProductResponseDTO responseDTO = new ProductResponseDTO();
        responseDTO.setId(product.getId());
        responseDTO.setName(product.getName());
        responseDTO.setDescription(product.getDescription());
        responseDTO.setPrice(product.getPrice());
        return responseDTO;
    }

    private Product convertToEntity(ProductRequestDTO request) {
        Product product = new Product();
        product.setName(request.getName());
        product.setDescription(request.getDescription());
        product.setPrice(request.getPrice());
        return product;
    }

    private static class ErrorResponse {
        private String message;

        public ErrorResponse(String message) {
            this.message = message;
        }

        // Getter and setter for message

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
