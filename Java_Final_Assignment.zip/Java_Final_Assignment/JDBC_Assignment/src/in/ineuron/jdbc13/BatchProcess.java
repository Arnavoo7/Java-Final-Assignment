package in.ineuron.jdbc13;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class BatchProcess {

        public static void main(String[] args) throws SQLException {

            Connection connection = null;
            PreparedStatement stmt = null;

            String url = "jdbc:postgresql://localhost:5432/proj2";
            String user = "root";
            String pass = "Password12";
            String input = "input.txt";

            try {

                connection = DriverManager.getConnection(url,user,pass);

                String insertQuery = "INSERT INTO your_table (name, age) VALUES (?, ?)";
                stmt = connection.prepareStatement(insertQuery);

                // Read data from the input file and add it to the batch
                BufferedReader reader = new BufferedReader(new FileReader(input));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] data = line.split(",");
                    String value1 = data[0];
                    String value2 = data[1];

                    stmt.setString(1, value1);
                    stmt.setString(2, value2);
                    stmt.addBatch();
                }
                reader.close();

                // Execute the batch update
                int[] updateCounts = stmt.executeBatch();

                // Process the update counts
                for (int count : updateCounts) {
                    System.out.println("Rows affected: " + count);
                }
            } catch (SQLException | java.io.IOException e) {
                e.printStackTrace();
            }
            finally {
                if(connection != null)
                    connection.close();
                else if (stmt != null)
                    stmt.close();

                }

            }


}
