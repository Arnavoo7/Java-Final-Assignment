package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servletdb")
public class ServletDB extends HttpServlet {
    private static final long serialVersionUID = 1L;
   
    private static final String URL = "jdbc:mysql://localhost:3306/proj1";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Password123#@!";
    
    

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            
        	Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            conn = DriverManager.getConnection(URL, USERNAME,PASSWORD);

            // Execute SQL query
            stmt = conn.createStatement();
            String sql = "SELECT * FROM project3";
            rs = stmt.executeQuery(sql);

            // Generate HTML table
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Table Data</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<table border='1'>");
            out.println("<tr><th>id</th><th>name</th><th>age</th></tr>");

            // Process the result set
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("id") + "</td>");
                out.println("<td>" + rs.getString("name") + "</td>");
                out.println("<td>" + rs.getInt("age") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }catch(ClassNotFoundException e) {
        	e.printStackTrace();
        }
        
        catch (SQLException e) {
            out.println("Failed to connect to the database.");
            e.printStackTrace();
        } finally {
            // Clean up resources
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            out.close();
        }
    }
}
