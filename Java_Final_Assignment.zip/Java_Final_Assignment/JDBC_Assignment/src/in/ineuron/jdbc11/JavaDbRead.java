package in.ineuron.jdbc11;

import java.sql.*;

public class JavaDbRead {

    public static void main(String[] args) {


        String url = "jdbc:mysql://localhost:3306/proj1";
        String user = "root";
        String pass = "Password123#@!";
        String query = "SELECT * FROM project3";

        try {

            //Step 1: Load and Register of Driver class automatically done

            //Step 2: Establishing the connection to DB
            Connection connect = DriverManager.getConnection(url, user, pass);

            //Step 3: Creating a PrepareStatement and send the query
            PreparedStatement stmt = connect.prepareStatement(query);

            //Step 4: Execute the query
            ResultSet result = stmt.executeQuery();

            //Step 5: Get the result
            while(result.next()){
                System.out.println("sid: "+result.getInt("sid")+ "  sname: "+result.getString("sname")+ "  sage: "+result.getInt("sage")+ "  saddress: "+result.getString("saddress"));
            }

        }
        catch(SQLException s){
            s.printStackTrace();
        }


    }
}
