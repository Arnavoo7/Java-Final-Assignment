package in.ineuron.coreJava5;

public abstract class AbstractB {

    //abstract method
    abstract void a();

    //concrete method
    void b(){
        System.out.println("Hi! from b.");
    }

    //override method
    void e(){
        System.out.println("Hi! from e.");
    }
}
