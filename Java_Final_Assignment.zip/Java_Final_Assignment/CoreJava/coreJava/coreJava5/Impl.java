package in.ineuron.coreJava5;

public class Impl extends AbstractB implements InterfaceA{

    //Giving the implementation for abstract methods`
    public void a(){
        System.out.println("Hey! from a");
    }

    //Specialized method
    public void c(){
        System.out.println("Hey! from Impl");
    }

    //Method overriding
    @Override
    public void e() {
        System.out.println("Hi! from eImpl");;
    }

    public static void main(String[] args) {
        Impl i = new Impl();
        i.a();
        i.c();
        i.b();
        i.d();
        i.e();
    }
}

/*
    Key Differences:

    - Using Abstract class we can achieve (0-100%) abstraction which means it can have abstract & concrete methods.
    - Using Interface we have 100% abstraction which means it only has abstract methods.

    - In java, multiple inheritance is not possible using classes (same for abstract classes)
    - But, in interface we can achieve multiple inheritance.

    - In Abstract class we can give a base implementation method which can be used by related classes.
    - In Interface it works as a contract or SRS (Software Requirement Specification) where unrelated classes
      give the method implementation for the abstract methods.

    - In Abstract class, all Access Modifiers are available to be used.
    - But, In Interface, by default the variables are (public static final) which makes the variable accessible
      by using Interface name, and methods by default are (public abstract).

     Note:

     - From Java 8 onwards, interface provides us with a feature of using default method which we can use to give
       a default method implementation which we can be used as a default body by unrelated classes, or we can override also.
 */
