package in.ineuron.coreJava2;

public class Child extends Parent {

    Child()
    {
        //super() is the first line as default which calls Parent class constructor.
        //Calling the current object Parameterized constructor.
        this(12);
        System.out.println("Hi! I'm from Child class.");
    }

    Child(int a)
    {
        System.out.println("Hey! I'm from a Parameterized constructor. The value is: "+a);
    }

    public static void main(String[] args) {

        /*
            - Here, Child() constructor is used with new keyword to create an object
              and also responsible to instantiate the object with the default values.
            - A default constructor will be automatically called whenever an object is created
              if user doesn't explicitly mention Non-parameterized or Parameterized constructor.
        */

        //Creating a Child class object
        Child c = new Child();


    }
}