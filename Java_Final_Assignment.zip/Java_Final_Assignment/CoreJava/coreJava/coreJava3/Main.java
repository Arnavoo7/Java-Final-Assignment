package in.ineuron.coreJava3;

import java.util.Scanner;

/*
    - Creating a custom Exception class (NegativeNumberException) and extending Exception class to get parents all
      functionalities.
    - Here, when the constructor of the NegativeNumberException(String message) is called the error message which is
      received is passed to parent constructor i.e, Exception class , and it has String parameterized constructor
      which store the error message allowing us to retrieve the message using getMessage().
*/

class NegativeNumberException extends Exception{
    public NegativeNumberException(String message){
        super(message);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter an integer: ");
        int a = sc.nextInt();

        try
        {
            if(a < 0)
                throw new NegativeNumberException("Negative no. is not allowed. Please input correct data.");
            else {
                System.out.println("The positive number is: "+ a);
            }
        }
        catch(NegativeNumberException n){  //n is the reference var of type NegativeNumberException which is pointing to the exception object which is caught by catch block
            System.out.println("Exception occurred is: \n\t"+n.getMessage());
        }
    }
}
