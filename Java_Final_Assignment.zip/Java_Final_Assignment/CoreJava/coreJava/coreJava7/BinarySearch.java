package in.ineuron.coreJava7;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {
    public static void main(String[] args) {

        // Sorted array
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the target value: ");
        int target = sc.nextInt();

        // Perform binary search
        int index = binarySearch(arr, target);

        // Display the result
        if (index != -1) {
            System.out.println("Target value found at index " + index);
        } else {
            System.out.println("Target value not found in the array.");
        }
    }

    // Binary search implementation
    private static int binarySearch(int[] arr, int target) {
        //Pointing to Lower Bound
        int low = 0;
        //Pointing to Upper Bound
        int high = arr.length - 1;

        while (low <= high) {

            int mid = (low + high) / 2;

            if (arr[mid] == target) {
                return mid;
            } else if (arr[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }

        }

        return -1; // Target value if not found then return -1.
    }
}
