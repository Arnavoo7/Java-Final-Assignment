package in.ineuron.coreJava10;

import java.util.*;

public class Ten {

    public static void main(String[] args) {

        int len;
        ArrayList<Integer> store = new ArrayList<>();

        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("Enter size of the list: ");
            len = sc.nextInt();

            System.out.println("Enter " + len + " numbers:");
            for (int i = 0; i < len; i++) {
                store.add(sc.nextInt());
            }

            //Sorting the elements in the list
            Collections.sort(store);

            Set<Integer> unique = new HashSet<>(store);
            List<Integer> antim = new ArrayList<>(unique);


            System.out.println("The second smallest element in the list is: "+antim.get(1));
            System.out.println("The second largest element in teh list is: "+antim.get(antim.size() - 2));
        }
        catch(IndexOutOfBoundsException | InputMismatchException i)
        {
            System.out.println("Please enter valid input.");
        }

    }

}
