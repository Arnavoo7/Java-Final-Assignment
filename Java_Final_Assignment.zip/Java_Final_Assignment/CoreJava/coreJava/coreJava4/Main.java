package in.ineuron.coreJava4;

import java.util.Scanner;


public class Main {


    public static void main(String[] args) {

        int choice;
        float amount = 0.0F;
        float bal = 0.0F;

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n\n***** Welcome! to iNeuron Bank Services *****\n");
            System.out.println("1. Deposit Amount");
            System.out.println("2. Withdraw Money");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");


            System.out.print("\nEnter your choice: ");
            choice = sc.nextInt();

            if (choice == 1 || choice == 2) {
                System.out.print("\nEnter amount: ");
                amount = sc.nextFloat();
            }


            BankServicesImpl services = new BankServicesImpl();

            switch (choice) {
                case 1:
                    bal = services.setDeposit(amount,bal);
                    break;

                case 2:
                    if(bal < amount)
                    {
                        System.out.println("Insufficient balance to withdraw.");
                    }
                    else
                        bal = services.setWithdraw(amount,bal);
                    break;

                case 3:
                    System.out.println("The Balance is: "+bal);
                    break;

                case 4:
                    System.exit(0);

                default:
                    System.out.println("Wrong choice! Please input valid input.");


            }
        }
    }
}
