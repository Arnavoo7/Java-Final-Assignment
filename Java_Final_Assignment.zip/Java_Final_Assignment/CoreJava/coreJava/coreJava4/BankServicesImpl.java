package in.ineuron.coreJava4;

public class BankServicesImpl implements IBank{

    private float balance=0.0F;

    @Override
    public float setDeposit(float amount,float bal){
        balance = bal;
        balance += amount;
        System.out.println("Amount : "+amount+ " deposited successfully!");
        return balance;

    }


    @Override
    public float setWithdraw(float amount,float bal) {
        balance = bal;
        System.out.println(balance);
        balance -= amount;
        System.out.println("Amount : "+amount+ " Withdrawn successfully!");
        return balance;

    }


}
