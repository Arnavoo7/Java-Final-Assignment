package in.ineuron.coreJava1;

public interface IShape
{

    //abstract methods
    void area();
    void perimeter();
}
